package com.greenfoxacademy.springstart.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.swing.text.AttributeSet;
import java.awt.*;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

@Controller
public class SayHelloWebController {
    String[] hellos = {"Mirëdita", "Ahalan", "Parev", "Zdravei", "Nei Ho", "Dobrý den", "Ahoj", "Goddag", "Goede dag, Hallo", "Hello", "Saluton", "Hei", "Bonjour",
            "Guten Tag", "Gia'sou", "Aloha", "Shalom", "Namaste", "Namaste", "Jó napot", "Halló", "Helló", "Góðan daginn", "Halo", "Aksunai", "Qanuipit", "Dia dhuit",
            "Salve", "Ciao", "Kon-nichiwa", "An-nyong Ha-se-yo", "Salvëte", "Ni hao", "Dzien' dobry", "Olá", "Bunã ziua", "Zdravstvuyte", "Hola", "Jambo", "Hujambo", "Hej",
            "Sa-wat-dee", "Merhaba", "Selam", "Vitayu", "Xin chào", "Hylo", "Sut Mae", "Sholem Aleychem", "Sawubona"};
    String[] fontC = {"red", "blue", "green", "yellow", "orange", "dark"};
    Random rnd = new Random();

    @RequestMapping("/web/greeting")
    public String sayHello(Model model, @RequestParam("name") String name) {
        int counter = rnd.nextInt(hellos.length);
        int count = rnd.nextInt(fontC.length);
        int fontS = 20 + rnd.nextInt(30);
        model.addAttribute("name", name);
        model.addAttribute("hellos", hellos[counter]);
        model.addAttribute("fontSize", fontS);
        model.addAttribute("fontColor", fontC[count]);
        return "greeting";
    }

}
